package com.example.laboratorio05.data

import androidx.room.RoomDatabase

abstract class MovieReviewerDatabase : RoomDatabase(){
    // TODO: complete MovieReviewerDatabase abstract class
}
package com.example.laboratorio05.repositories

class ActorRepository() {
        // TODO: complete Actor ActorRepository
}
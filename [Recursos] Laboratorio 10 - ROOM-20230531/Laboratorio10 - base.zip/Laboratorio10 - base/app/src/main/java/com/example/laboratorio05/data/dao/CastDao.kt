package com.example.laboratorio05.data.dao

interface CastDao {
    // TODO: Create insert casting method
}
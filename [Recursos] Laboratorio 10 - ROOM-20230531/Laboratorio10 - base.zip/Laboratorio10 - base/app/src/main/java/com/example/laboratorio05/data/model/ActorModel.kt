package com.example.laboratorio05.data.model

data class ActorModel (
    var actorId: Long = 0L,
    val name: String,
)


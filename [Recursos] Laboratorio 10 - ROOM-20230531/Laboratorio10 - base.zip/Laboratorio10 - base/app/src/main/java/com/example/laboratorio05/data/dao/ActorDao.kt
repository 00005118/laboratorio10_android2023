package com.example.laboratorio05.data.dao

interface ActorDao {
    // TODO: create getAllActors method
    // TODO: create insertActor method
}
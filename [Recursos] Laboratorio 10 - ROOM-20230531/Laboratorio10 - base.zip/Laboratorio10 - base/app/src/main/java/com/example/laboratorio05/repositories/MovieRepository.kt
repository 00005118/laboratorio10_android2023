package com.example.laboratorio05.repositories

import com.example.laboratorio05.data.dao.MovieDao
import com.example.laboratorio05.data.model.MovieModel

class MovieRepository(private val moviesDao: MovieDao) {

    // TODO: complete getMovies method
    fun getMovies() = null

    // TODO: complete addMovies method
    fun addMovies(movie: MovieModel) = null

    // TODO: complete getMoviesWithActors method
    fun getMoviesWithActors(id: Int) = null

}
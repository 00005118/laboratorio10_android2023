package com.example.laboratorio05.data.dao

interface MovieDao {
    // TODO: create getAllMovies method
    // TODO: create insertMovie method
    // TODO: create getMovieWithActorsById method
}
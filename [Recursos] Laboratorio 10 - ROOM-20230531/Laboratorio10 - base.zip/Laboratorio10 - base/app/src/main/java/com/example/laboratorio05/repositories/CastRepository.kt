package com.example.laboratorio05.repositories

class CastRepository() {
    // TODO: complete Actor ActorRepository
}